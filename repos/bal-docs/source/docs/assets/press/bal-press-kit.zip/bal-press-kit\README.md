# Bitcoin After Life — Press Kit

Everything a journalist, podcaster, or researcher needs to cover **Bitcoin After Life (BAL)**.

For anything not covered here: **press@bitcoin-after.life**

---

## One-line summary

Bitcoin After Life (BAL) is an open-source Electrum plugin for decentralized Bitcoin
inheritance: you set your heirs and a delivery date, your key signs a time-locked
transaction, and a network of independent Will-Executor servers broadcasts it on that
date. No notary, no lawyer, no custodian.

---

## Boilerplate

### Short (≈25 words)

> Bitcoin After Life (BAL) is an open-source Electrum plugin enabling decentralized
> Bitcoin inheritance through time-locked transactions and a network of independent
> Will-Executor servers — no notary, no custodian.

### Medium (≈50 words)

> Bitcoin After Life (BAL) is an open-source, non-custodial protocol and Electrum plugin
> for Bitcoin inheritance. Owners pre-sign a time-locked transaction that Bitcoin nodes
> reject until a chosen date; a decentralized network of incentivized Will-Executor
> servers then broadcasts it. Keys never leave the owner's device, and no single party
> can steal, alter, or accelerate anything.

### Long (≈100 words)

> Bitcoin After Life (BAL) is an open-source protocol and Electrum plugin that makes
> Bitcoin inheritance possible without notaries, lawyers, or custodians. The owner
> selects heirs and a delivery date; the plugin builds a time-locked transaction,
> Electrum signs it locally, and a network of independent Will-Executor servers stores
> it and broadcasts it to the Bitcoin network on that date. Bitcoin's own consensus
> rules reject the transaction until the date arrives, so no one can execute it early.
> Security comes from redundancy and competition between servers, not from trusting any
> single one. The project is fully open source and funded entirely in Bitcoin.

---

## Fast facts

| | |
| --- | --- |
| **Name** | Bitcoin After Life (BAL) |
| **What it is** | Open-source protocol + Electrum plugin for decentralized Bitcoin inheritance |
| **Current version** | Always check the main website — https://bitcoin-after.life — for the latest version and Electrum compatibility |
| **License** | MIT (open source) |
| **Cost** | Free plugin; Will-Executors are paid an on-chain fee only when they successfully broadcast |
| **Custody** | Non-custodial — keys never leave the user's device |
| **Listed on** | Electrum's official third-party plugin directory |
| **Origin** | First published on BitcoinTalk, 31 October 2024, signed *Svātantrya* |
| **Funding** | 100% Bitcoin — no fiat currency involved anywhere in the project |
| **Team** | Pseudonymous by design |

---

## Official links

Use these to verify that a channel really is ours.

| Resource | Link |
| --- | --- |
| Website | https://bitcoin-after.life |
| Manual / documentation | https://bitcoin-after.life/docs/ |
| Plugin source & releases | https://bitcoin-after.life/gitea/bitcoinafterlife/bal-electrum-plugin |
| Will-Executor server source | https://bitcoin-after.life/gitea/bitcoinafterlife/bal-server |
| Documentation source | https://bitcoin-after.life/gitea/bitcoinafterlife/bal-docs |
| Public Will-Executor directory (WeList) | https://welist.bitcoin-after.life/ |
| X (Twitter) | https://x.com/BitcoinAfterLif |
| Nostr | npub1n0lp09j9ymm8hr3uepyu2va2dn4wks8xu5jqgzn72y9ech7una5q75efj2 |

---

## Verifying our communications (PGP)

Official announcements can be signed with our PGP key.

- **Public key:** https://bitcoin-after.life/svatantrya.asc
- **Fingerprint:** `A847 D004 DB91 6107 11CA 6A0D FE75 6706 E833 E0D1`

To verify a signed message, import the key above and check the signature against this
fingerprint. If a fingerprint does not match, the message is not from us.

---

## Brand assets in this archive

| Path | Asset |
| --- | --- |
| `logos/logo.svg` | Full logo |
| `logos/logo-mark-black.svg` | Logo mark — dark (for light backgrounds) |
| `logos/logo-mark-white.svg` | Logo mark — light (for dark backgrounds) |
| `logos/logo-lockup-black.svg` | Full lockup — dark |
| `logos/logo-lockup-white.svg` | Full lockup — light |
| `screenshots/will-tab.png` | The WILL tab in the plugin |

Please don't stretch, recolor, or add effects to the mark.

---

## Two things we ask reporters to get right

1. BAL is **listed in Electrum's third-party plugin directory** — it is **not** built,
   endorsed, or reviewed by the Electrum developers. Third-party plugins are not vetted
   by them.
2. BAL is **non-custodial**. It never takes control of anyone's coins or keys.
   Will-Executors hold only a pre-signed transaction and cannot alter, spend, or
   accelerate it.

Questions, corrections, interview requests: **press@bitcoin-after.life**
